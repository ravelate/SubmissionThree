package com.fianku.firstsubmission.ui.main

import android.content.ContentValues
import android.util.Log
import androidx.lifecycle.*
import com.fianku.firstsubmission.api.ApiConfig
import com.fianku.firstsubmission.api.ListStoryItem

import com.fianku.firstsubmission.api.StoryResponse
import com.fianku.firstsubmission.customView.Event
import com.fianku.firstsubmission.customView.SettingPreferences
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainViewModel(private val pref: SettingPreferences): ViewModel() {
    private val _story = MutableLiveData<List<ListStoryItem>?>()
    val story: LiveData<List<ListStoryItem>?> = _story
    private val _snackbarText = MutableLiveData<Event<String>>()
    val snackbarText: LiveData<Event<String>> = _snackbarText
    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading
    fun getUserTokens(): LiveData<String?> {
        return pref.getUserToken().asLiveData()
    }
    fun getUserNames(): LiveData<String?> {
        return pref.getUserName().asLiveData()
    }
    fun getStory(auth: String) {
        _isLoading.value = true
        val client = ApiConfig.getApiService().getStory(auth)
        client.enqueue(object : Callback<StoryResponse> {
            override fun onResponse(
                call: Call<StoryResponse>,
                response: Response<StoryResponse>
            ) {
                _isLoading.value =false
                if (response.isSuccessful && response.body() != null) {
                    _story.value = response.body()?.listStory as List<ListStoryItem>?
                    _snackbarText.value = Event(response.body()?.message.toString())
                } else {
                    _snackbarText.value = Event("Error")
                    Log.e(ContentValues.TAG, "onFailure but response: ${response.message()}")
                }
            }
            override fun onFailure(call: Call<StoryResponse>, t: Throwable) {
                _isLoading.value = false
                Log.e(ContentValues.TAG, "onFailure: ${t.message}")
            }
        })
    }
}