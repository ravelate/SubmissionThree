package com.fianku.firstsubmission.customView

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.fianku.firstsubmission.ui.addPhoto.PhotoViewModel
import com.fianku.firstsubmission.ui.detailUser.DetailUserViewModel
import com.fianku.firstsubmission.ui.login.LoginViewModel
import com.fianku.firstsubmission.ui.main.MainViewModel

class ViewModelFactory(private val pref: SettingPreferences) : ViewModelProvider.NewInstanceFactory() {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        return when {
            modelClass.isAssignableFrom(MainViewModel::class.java) -> {
                MainViewModel(pref) as T
            }
            modelClass.isAssignableFrom(LoginViewModel::class.java) -> {
                LoginViewModel(pref) as T
            }
            modelClass.isAssignableFrom(DetailUserViewModel::class.java) -> {
                DetailUserViewModel(pref) as T
            }
            modelClass.isAssignableFrom(PhotoViewModel::class.java) -> {
                PhotoViewModel(pref) as T
            }
            else -> throw IllegalArgumentException("Unknown ViewModel class: " + modelClass.name)
        }
    }
}