package com.fianku.firstsubmission.adapter

import android.app.Activity
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.app.ActivityOptionsCompat
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.fianku.firstsubmission.api.ListStoryItem
import com.fianku.firstsubmission.R
import com.fianku.firstsubmission.ui.detailUser.DetailActivity
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.*

class StoryAdapter(private val listUser: List<ListStoryItem>?) : RecyclerView.Adapter<StoryAdapter.ViewHolder>() {

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int) =
        ViewHolder(LayoutInflater.from(viewGroup.context).inflate(R.layout.item_story, viewGroup, false))

    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {
        viewHolder.tvName.text = listUser?.get(position)?.name ?: "-"
        viewHolder.tvDate.text = listUser?.get(position)?.createdAt?.withDateFormat() ?: "-"
        Glide.with(viewHolder.itemView.context)
            .load("${listUser?.get(position)?.photoUrl}")
            .into(viewHolder.imgItemPhoto)
        viewHolder.tvDesc.text = listUser?.get(position)?.description ?: "-"
        viewHolder.bind(listUser?.get(position))
    }
    override fun getItemCount() = listUser?.size ?: 0
    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvName: TextView = view.findViewById(R.id.tvName)
        val tvDate: TextView = view.findViewById(R.id.tvDate)
        val tvDesc: TextView = view.findViewById(R.id.tvDesc)
        val imgItemPhoto: ImageView = view.findViewById(R.id.imgItemPhoto)
        fun bind(user: ListStoryItem?){
            itemView.setOnClickListener {
                val i = Intent(itemView.context, DetailActivity::class.java)
                i.putExtra("data",user)
                val optionsCompat: ActivityOptionsCompat =
                    ActivityOptionsCompat.makeSceneTransitionAnimation(
                        itemView.context as Activity,
                        androidx.core.util.Pair(imgItemPhoto, "profile"),
                        androidx.core.util.Pair(tvName, "name"),
                        androidx.core.util.Pair(tvDate, "date"),
                        androidx.core.util.Pair(tvDesc, "description"),
                    )
                itemView.context.startActivity(i, optionsCompat.toBundle())
            }
        }
    }
    private fun String.withDateFormat(): String {
        val format = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US)
        val date = format.parse(this) as Date
        return DateFormat.getDateInstance(DateFormat.FULL).format(date)
    }
}